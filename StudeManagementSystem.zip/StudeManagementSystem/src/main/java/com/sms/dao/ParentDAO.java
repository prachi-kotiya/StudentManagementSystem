package com.sms.dao;

import com.sms.model.Parent;
import com.sms.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ParentDAO {

    // Add Parent
    public boolean addParent(Parent parent) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO parents(parent_id, full_name, email, phone, occupation, address) VALUES(?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, parent.getParentId());
            ps.setString(2, parent.getFullName());
            ps.setString(3, parent.getEmail());
            ps.setString(4, parent.getPhone());
            ps.setString(5, parent.getOccupation());
            ps.setString(6, parent.getAddress());

            status = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // Get All Parents
    public List<Parent> getAllParents() {

        List<Parent> list = new ArrayList<>();

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM parents";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Parent p = new Parent();

                p.setId(rs.getInt("id"));
                p.setParentId(rs.getString("parent_id"));
                p.setFullName(rs.getString("full_name"));
                p.setEmail(rs.getString("email"));
                p.setPhone(rs.getString("phone"));
                p.setOccupation(rs.getString("occupation"));
                p.setAddress(rs.getString("address"));

                list.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // Get Parent By ID
    public Parent getParentById(int id) {

        Parent parent = null;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM parents WHERE id=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                parent = new Parent();

                parent.setId(rs.getInt("id"));
                parent.setParentId(rs.getString("parent_id"));
                parent.setFullName(rs.getString("full_name"));
                parent.setEmail(rs.getString("email"));
                parent.setPhone(rs.getString("phone"));
                parent.setOccupation(rs.getString("occupation"));
                parent.setAddress(rs.getString("address"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return parent;
    }

    // Update Parent
    public boolean updateParent(Parent parent) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "UPDATE parents SET parent_id=?, full_name=?, email=?, phone=?, occupation=?, address=? WHERE id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, parent.getParentId());
            ps.setString(2, parent.getFullName());
            ps.setString(3, parent.getEmail());
            ps.setString(4, parent.getPhone());
            ps.setString(5, parent.getOccupation());
            ps.setString(6, parent.getAddress());
            ps.setInt(7, parent.getId());

            status = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // Delete Parent
    public boolean deleteParent(int id) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "DELETE FROM parents WHERE id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            status = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
}