package com.sms.dao;

import com.sms.model.Student;
import com.sms.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class StudentDAO {

    // Add Student
    public boolean addStudent(Student student) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO students(student_id, full_name, email, phone, course, semester, address) VALUES(?,?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, student.getStudentId());
            ps.setString(2, student.getFullName());
            ps.setString(3, student.getEmail());
            ps.setString(4, student.getPhone());
            ps.setString(5, student.getCourse());
            ps.setString(6, student.getSemester());
            ps.setString(7, student.getAddress());

            status = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // Get All Students
    public List<Student> getAllStudents() {

        List<Student> list = new ArrayList<>();

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM students";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Student s = new Student();

                s.setId(rs.getInt("id"));
                s.setStudentId(rs.getString("student_id"));
                s.setFullName(rs.getString("full_name"));
                s.setEmail(rs.getString("email"));
                s.setPhone(rs.getString("phone"));
                s.setCourse(rs.getString("course"));
                s.setSemester(rs.getString("semester"));
                s.setAddress(rs.getString("address"));

                list.add(s);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    // Get Student By ID
public Student getStudentById(int id) {

    Student student = null;

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT * FROM students WHERE id = ?";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {

            student = new Student();

            student.setId(rs.getInt("id"));
            student.setStudentId(rs.getString("student_id"));
            student.setFullName(rs.getString("full_name"));
            student.setEmail(rs.getString("email"));
            student.setPhone(rs.getString("phone"));
            student.setCourse(rs.getString("course"));
            student.setSemester(rs.getString("semester"));
            student.setAddress(rs.getString("address"));
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return student;
}
public boolean updateStudent(Student student) {

    boolean status = false;

    try {

        Connection con = DBConnection.getConnection();

        String sql = "UPDATE students SET student_id=?, full_name=?, email=?, phone=?, course=?, semester=?, address=? WHERE id=?";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setString(1, student.getStudentId());
        ps.setString(2, student.getFullName());
        ps.setString(3, student.getEmail());
        ps.setString(4, student.getPhone());
        ps.setString(5, student.getCourse());
        ps.setString(6, student.getSemester());
        ps.setString(7, student.getAddress());
        ps.setInt(8, student.getId());

        status = ps.executeUpdate() > 0;

    } catch (Exception e) {
        e.printStackTrace();
    }

    return status;
}
public boolean deleteStudent(int id) {

    boolean status = false;

    try {

        Connection con = DBConnection.getConnection();

        String sql = "DELETE FROM students WHERE id=?";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setInt(1, id);

        status = ps.executeUpdate() > 0;

    } catch (Exception e) {
        e.printStackTrace();
    }

    return status;
}
// Search Students
public List<Student> searchStudents(String keyword) {

    List<Student> list = new ArrayList<>();

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT * FROM students WHERE student_id LIKE ? OR full_name LIKE ? OR email LIKE ?";

        PreparedStatement ps = con.prepareStatement(sql);

        String search = "%" + keyword + "%";

        ps.setString(1, search);
        ps.setString(2, search);
        ps.setString(3, search);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            Student s = new Student();

            s.setId(rs.getInt("id"));
            s.setStudentId(rs.getString("student_id"));
            s.setFullName(rs.getString("full_name"));
            s.setEmail(rs.getString("email"));
            s.setPhone(rs.getString("phone"));
            s.setCourse(rs.getString("course"));
            s.setSemester(rs.getString("semester"));
            s.setAddress(rs.getString("address"));

            list.add(s);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
}
}