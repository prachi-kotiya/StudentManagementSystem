package com.sms.dao;
import com.sms.model.Attendance;
import com.sms.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AttendanceDAO {

    public boolean addAttendance(Attendance attendance) {

        boolean status = false;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO attendance(student_id, attendance_date, status) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, attendance.getStudentId());
            ps.setDate(2, attendance.getAttendanceDate());
            ps.setString(3, attendance.getStatus());

            status = ps.executeUpdate() > 0;

        } catch (Exception e) {

            System.out.println("========== DATABASE ERROR ==========");
            e.printStackTrace();

        }

        return status;
    }

    /**
     *
     * @return
     */
    public List<Attendance> getAllAttendance() {

    List<Attendance> list = new ArrayList<>();

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT a.id, a.student_id, s.full_name, a.attendance_date, a.status "
                   + "FROM attendance a "
                   + "JOIN students s ON a.student_id = s.id";

        PreparedStatement ps = con.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            Attendance attendance = new Attendance();

            attendance.setId(rs.getInt("id"));
            attendance.setStudentId(rs.getInt("student_id"));
            attendance.setStudentName(rs.getString("full_name"));
            attendance.setAttendanceDate(rs.getDate("attendance_date"));
            attendance.setStatus(rs.getString("status"));

            list.add(attendance);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
}

    public void updateAttendance(Attendance attendance) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Attendance getAttendanceById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void deleteAttendance(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}