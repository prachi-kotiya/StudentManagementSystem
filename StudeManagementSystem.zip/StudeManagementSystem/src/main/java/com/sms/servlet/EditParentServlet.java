package com.sms.servlet;

import com.sms.dao.ParentDAO;
import com.sms.model.Parent;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/EditParentServlet")
public class EditParentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get ID from URL
        int id = Integer.parseInt(request.getParameter("id"));

        // Fetch parent from database
        ParentDAO dao = new ParentDAO();
        Parent parent = dao.getParentById(id);

        if (parent != null) {
            request.setAttribute("parent", parent);
            request.getRequestDispatcher("/admin/edit-parent.jsp")
                   .forward(request, response);
        } else {
            response.getWriter().println("Parent not found.");
        }
    }
}