package com.sms.servlet;

import com.sms.dao.UserDAO;
import com.sms.model.User;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        UserDAO dao = new UserDAO();

        User user = dao.loginUser(username, password);

        if (user != null) {

            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            switch (user.getRole()) {

                case "Admin":
                    response.sendRedirect("admin/dashboard.jsp");
                    break;

                case "Teacher":
                    response.sendRedirect("teacher/dashboard.jsp");
                    break;

                case "Student":
                    response.sendRedirect("student/dashboard.jsp");
                    break;

                case "Parent":
                    response.sendRedirect("parent/dashboard.jsp");
                    break;

                default:
                    response.sendRedirect("login.html");
            }

        } else {

            response.getWriter().println("Invalid Username or Password");

        }

    }
}