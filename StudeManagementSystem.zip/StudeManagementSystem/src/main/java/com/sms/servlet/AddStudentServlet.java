package com.sms.servlet;

import com.sms.dao.StudentDAO;
import com.sms.model.Student;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddStudentServlet")
public class AddStudentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Student student = new Student();

        student.setStudentId(request.getParameter("studentId"));
        student.setFullName(request.getParameter("fullName"));
        student.setEmail(request.getParameter("email"));
        student.setPhone(request.getParameter("phone"));
        student.setCourse(request.getParameter("course"));
        student.setSemester(request.getParameter("semester"));
        student.setAddress(request.getParameter("address"));

        StudentDAO dao = new StudentDAO();

        boolean status = dao.addStudent(student);

        if (status) {
         response.sendRedirect(request.getContextPath() + "/StudentsServlet");
        } else {
            response.getWriter().println("Failed to add student.");
        }
    }
}