<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.sms.model.Student" %>

<!DOCTYPE html>
<html>
<head>
    <title>Students</title>

    <style>
        body{
            font-family:Arial;
            background:#f4f6f9;
            margin:30px;
        }

        h2{
            color:#333;
        }

        table{
            width:100%;
            border-collapse:collapse;
            background:white;
        }

        th,td{
            padding:12px;
            border:1px solid #ddd;
            text-align:center;
        }

        th{
            background:#4CAF50;
            color:white;
        }

        tr:nth-child(even){
            background:#f2f2f2;
        }

        .btn{
            padding:8px 15px;
            text-decoration:none;
            border-radius:5px;
            color:white;
        }

        .edit{
            background:#2196F3;
        }

        .delete{
            background:#f44336;
        }

        .add{
            background:#4CAF50;
        }

    </style>

</head>

<body>

<h2>Student List</h2>
<div class="d-flex justify-content-between mb-3">

<form action="${pageContext.request.contextPath}/StudentsServlet" method="get" class="d-flex">

<input
type="text"
name="search"
class="form-control me-2"
placeholder="Search by ID, Name or Email">

<button class="btn btn-primary">
Search
</button>

</form>

<a href="${pageContext.request.contextPath}/admin/add-student.jsp"
class="btn btn-success">
+ Add Student
</a>
<a href="${pageContext.request.contextPath}/ExportStudentPDFServlet"
class="btn btn-danger">

<i class="bi bi-file-earmark-pdf"></i>

Export PDF

</a>
</div>

<br><br>

<table>

<tr>

<th>ID</th>
<th>Student ID</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>Course</th>
<th>Semester</th>
<th>Action</th>

</tr>

<%
List<Student> list=(List<Student>)request.getAttribute("studentList");

if(list!=null){

for(Student s:list){
%>

<tr>

<td><%=s.getId()%></td>

<td><%=s.getStudentId()%></td>

<td><%=s.getFullName()%></td>

<td><%=s.getEmail()%></td>

<td><%=s.getPhone()%></td>

<td><%=s.getCourse()%></td>

<td><%=s.getSemester()%></td>

<td>

<a href="${pageContext.request.contextPath}/EditStudentServlet?id=<%=s.getId()%>" class="btn edit">
    Edit
</a>
<a href="${pageContext.request.contextPath}/DeleteStudentServlet?id=<%=s.getId()%>"
   class="btn delete"
   onclick="return confirm('Are you sure you want to delete this student?');">
    Delete
</a>
</td>

</tr>

<%
}
}
%>

</table>

</body>
</html>