<%@ page contentType="text/html;charset=UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Add Result</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-primary text-white">

<h3>Add Student Result</h3>

</div>

<div class="card-body">

<form action="${pageContext.request.contextPath}/AddResultServlet" method="post">

<div class="mb-3">

<label class="form-label">Student ID</label>

<input
type="number"
name="studentId"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">Subject</label>

<input
type="text"
name="subject"
class="form-control"
placeholder="Enter Subject Name"
required>

</div>

<div class="mb-3">

<label class="form-label">Marks</label>

<input
type="number"
step="0.01"
name="marks"
class="form-control"
placeholder="Enter Marks"
required>

</div>

<div class="mb-3">

<label class="form-label">Grade</label>

<select
name="grade"
class="form-select"
required>

<option value="">Select Grade</option>
<option value="A+">A+</option>
<option value="A">A</option>
<option value="B+">B+</option>
<option value="B">B</option>
<option value="C">C</option>
<option value="D">D</option>
<option value="F">F</option>

</select>

</div>

<div class="mb-3">

<label class="form-label">Exam Date</label>

<input
type="date"
name="examDate"
class="form-control"
required>

</div>

<button type="submit" class="btn btn-success">

Save Result

</button>

<a href="${pageContext.request.contextPath}/ResultListServlet"
class="btn btn-secondary">

View Results

</a>

</form>

</div>

</div>

</div>

</body>

</html>