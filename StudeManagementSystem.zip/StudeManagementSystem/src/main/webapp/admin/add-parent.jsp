<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Parent</title>

    <style>
        body{
            font-family:Arial;
            background:#f4f6f9;
            padding:30px;
        }

        .container{
            width:500px;
            margin:auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px rgba(0,0,0,.1);
        }

        input,textarea{
            width:100%;
            padding:10px;
            margin:8px 0;
            box-sizing:border-box;
        }

        button{
            background:#4CAF50;
            color:white;
            border:none;
            padding:10px 20px;
            cursor:pointer;
        }
    </style>

</head>

<body>

<div class="container">

<h2>Add Parent</h2>

<form action="${pageContext.request.contextPath}/AddParentServlet" method="post">

<label>Parent ID</label>
<input type="text" name="parentId" required>

<label>Full Name</label>
<input type="text" name="fullName" required>

<label>Email</label>
<input type="email" name="email" required>

<label>Phone</label>
<input type="text" name="phone" required>

<label>Occupation</label>
<input type="text" name="occupation" required>

<label>Address</label>
<textarea name="address"></textarea>

<br><br>

<button type="submit">Add Parent</button>

</form>

</div>

</body>
</html>