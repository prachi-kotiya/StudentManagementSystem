<%@page import="java.util.List"%>
<%@page import="com.sms.model.Fee"%>

<%
List<Fee> feeList = (List<Fee>)request.getAttribute("feeList");
%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Fees</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container mt-5">

<h2>Fee Records</h2>

<a href="add-fee.jsp" class="btn btn-primary mb-3">
Add Fee
</a>

<table class="table table-bordered table-striped">

<tr>

<th>ID</th>
<th>Student</th>
<th>Amount</th>
<th>Fee Type</th>
<th>Date</th>
<th>Status</th>

</tr>

<%
if(feeList!=null){

for(Fee fee: feeList){
%>

<tr>

<td><%=fee.getId()%></td>

<td><%=fee.getStudentName()%></td>

<td>? <%=fee.getAmount()%></td>

<td><%=fee.getFeeType()%></td>

<td><%=fee.getPaymentDate()%></td>

<td>

<%
if(fee.getStatus().equals("Paid")){
%>

<span class="badge bg-success">Paid</span>

<%
}else{
%>

<span class="badge bg-danger">Pending</span>

<%
}
%>

</td>

</tr>

<%
}
}
%>

</table>

</div>

</body>

</html>