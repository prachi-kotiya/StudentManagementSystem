<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.sms.model.Parent" %>

<%
List<Parent> list = (List<Parent>) request.getAttribute("parentList");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Parents</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    margin:30px;
}

h2{
    color:#333;
}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
}

th,td{
    padding:12px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#2c3e50;
    color:white;
}

tr:nth-child(even){
    background:#f2f2f2;
}

.btn{
    padding:8px 15px;
    text-decoration:none;
    border-radius:5px;
    color:white;
}

.add{
    background:#4CAF50;
}

.edit{
    background:#2196F3;
}

.delete{
    background:#f44336;
}

</style>

</head>

<body>

<h2>Parent List</h2>

<a href="${pageContext.request.contextPath}/admin/add-parent.jsp" class="btn add">
    + Add Parent
</a>

<br><br>

<table>

<tr>
    <th>ID</th>
    <th>Parent ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Occupation</th>
    <th>Action</th>
</tr>

<%
if(list != null){
    for(Parent p : list){
%>

<tr>

<td><%=p.getId()%></td>
<td><%=p.getParentId()%></td>
<td><%=p.getFullName()%></td>
<td><%=p.getEmail()%></td>
<td><%=p.getPhone()%></td>
<td><%=p.getOccupation()%></td>

<td>

<a href="${pageContext.request.contextPath}/EditParentServlet?id=<%=p.getId()%>"
   class="btn edit">
   Edit
</a>

<a href="${pageContext.request.contextPath}/DeleteParentServlet?id=<%=p.getId()%>"
   class="btn delete"
   onclick="return confirm('Are you sure you want to delete this parent?');">
   Delete
</a>

</td>

</tr>

<%
    }
}
%>

</table>

</body>
</html>