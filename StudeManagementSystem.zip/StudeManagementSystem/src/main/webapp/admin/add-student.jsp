<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Student</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="container">

    <h2>Add New Student</h2>

    <form action="${pageContext.request.contextPath}/AddStudentServlet" method="post">

        <label>Student ID</label>
        <input type="text" name="studentId" required>

        <label>Full Name</label>
        <input type="text" name="fullName" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Phone</label>
        <input type="text" name="phone" required>

        <label>Course</label>
        <input type="text" name="course" required>

        <label>Semester</label>
        <input type="text" name="semester" required>

        <label>Address</label>
        <textarea name="address" rows="4"></textarea>

        <br><br>

        <button type="submit">Add Student</button>
        
    </form>

</div>

</body>
</html>