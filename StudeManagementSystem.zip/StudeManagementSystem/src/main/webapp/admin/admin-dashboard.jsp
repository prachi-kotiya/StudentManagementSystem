<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>

body{
    background:#f4f6f9;
}

.sidebar{
    width:250px;
    min-height:100vh;
    background:#212529;
}

.sidebar .nav-link{
    color:white;
    padding:12px;
    border-radius:8px;
    margin-bottom:5px;
}

.sidebar .nav-link:hover{
    background:#0d6efd;
}

.card{
    border:none;
    border-radius:15px;
}

.card i{
    font-size:40px;
}

</style>

</head>

<body>

<div class="d-flex">

    <!-- Sidebar -->

    <div class="sidebar p-3">

        <h3 class="text-white text-center mb-4">
            SMS Admin
        </h3>

        <ul class="nav flex-column">

            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/DashboardServlet" class="nav-link">
                    <i class="bi bi-speedometer2"></i>
                    Dashboard
                </a>
            </li>

            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/StudentsServlet" class="nav-link">
                    <i class="bi bi-mortarboard-fill"></i>
                    Students
                </a>
            </li>

            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/TeachersServlet" class="nav-link">
                    <i class="bi bi-person-workspace"></i>
                    Teachers
                </a>
            </li>

            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/AttendanceListServlet" class="nav-link">
                    <i class="bi bi-calendar-check"></i>
                    Attendance
                </a>
            </li>

            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/FeeListServlet" class="nav-link">
                    <i class="bi bi-cash-stack"></i>
                    Fees
                </a>
            </li>

            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/ResultListServlet" class="nav-link">
                    <i class="bi bi-journal-check"></i>
                    Results
                </a>
            </li>

            <li class="nav-item">
                <a href="${pageContext.request.contextPath}/logout.jsp" class="nav-link">
                    <i class="bi bi-box-arrow-right"></i>
                    Logout
                </a>
            </li>

        </ul>

    </div>

    <!-- Main Content -->

    <div class="container-fluid p-4">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <h2>
                Admin Dashboard
            </h2>

            <h5>
                Welcome Admin 👋
            </h5>

        </div>

        <div class="row g-4">

            <div class="col-md-4">

                <div class="card bg-primary text-white shadow">

                    <div class="card-body text-center">

                        <i class="bi bi-mortarboard-fill"></i>

                        <h5 class="mt-3">
                            Students
                        </h5>

                        <h2>${studentCount}</h2>

                    </div>

                </div>

            </div>

            <div class="col-md-4">

                <div class="card bg-success text-white shadow">

                    <div class="card-body text-center">

                        <i class="bi bi-person-workspace"></i>

                        <h5 class="mt-3">
                            Teachers
                        </h5>

                        <h2>${teacherCount}</h2>

                    </div>

                </div>

            </div>

            <div class="col-md-4">

                <div class="card bg-warning text-dark shadow">

                    <div class="card-body text-center">

                        <i class="bi bi-calendar-check"></i>

                        <h5 class="mt-3">
                            Attendance
                        </h5>

                        <h2>${attendanceCount}</h2>

                    </div>

                </div>

            </div>

            <div class="col-md-6">

                <div class="card bg-info text-white shadow">

                    <div class="card-body text-center">

                        <i class="bi bi-cash-stack"></i>

                        <h5 class="mt-3">
                            Fees
                        </h5>

                        <h2>${feeCount}</h2>

                    </div>

                </div>

            </div>

            <div class="col-md-6">

                <div class="card bg-danger text-white shadow">

                    <div class="card-body text-center">

                        <i class="bi bi-journal-check"></i>

                        <h5 class="mt-3">
                            Results
                        </h5>

                        <h2>${resultCount}</h2>

                    </div>

                </div>

            </div>

        </div>

        <div class="row mt-5">

            <div class="col-md-8">

                <div class="card shadow">

                    <div class="card-header">

                        Student Statistics

                    </div>

                    <div class="card-body">

                        <canvas id="myChart"></canvas>

                    </div>

                </div>

            </div>

            <div class="col-md-4">

                <div class="card shadow">

                    <div class="card-header">

                        Recent Activity

                    </div>

                    <div class="card-body">

                        <ul class="list-group">

                            <li class="list-group-item">
                                ✅ Student Added
                            </li>

                            <li class="list-group-item">
                                ✅ Teacher Added
                            </li>

                            <li class="list-group-item">
                                ✅ Attendance Updated
                            </li>

                            <li class="list-group-item">
                                ✅ Fee Received
                            </li>

                            <li class="list-group-item">
                                ✅ Result Uploaded
                            </li>

                        </ul>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

const ctx=document.getElementById('myChart');

new Chart(ctx,{

type:'bar',

data:{

labels:['Students','Teachers','Attendance','Fees','Results'],

datasets:[{

label:'Records',

data:[
${studentCount},
${teacherCount},
${attendanceCount},
${feeCount},
${resultCount}
]

}]

}

});

</script>

</body>

</html>