<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.sms.model.Teacher" %>

<%
List<Teacher> list = (List<Teacher>) request.getAttribute("teacherList");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Teachers</title>

<style>
body{
    font-family:Arial;
    background:#f4f6f9;
    margin:30px;
}

h2{
    color:#333;
}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
}

th,td{
    padding:12px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#2c3e50;
    color:white;
}

tr:nth-child(even){
    background:#f2f2f2;
}

.btn{
    padding:8px 15px;
    text-decoration:none;
    border-radius:5px;
    color:white;
}

.add{
    background:#4CAF50;
}

.edit{
    background:#2196F3;
}

.delete{
    background:#f44336;
}
</style>

</head>

<body>

<h2>Teacher List</h2>

<div class="d-flex justify-content-between mb-3">

<form action="${pageContext.request.contextPath}/TeachersServlet"
      method="get"
      class="d-flex">

<input
type="text"
name="search"
class="form-control me-2"
placeholder="Search Teacher">

<button class="btn btn-primary">

Search

</button>

</form>

<a href="${pageContext.request.contextPath}/admin/add-teacher.jsp"
class="btn btn-success">

+ Add Teacher

</a>

</div>

<br><br>

<table>

<tr>
    <th>ID</th>
    <th>Teacher ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Department</th>
    <th>Qualification</th>
    <th>Action</th>
</tr>

<%
if(list != null){
    for(Teacher t : list){
%>

<tr>

<td><%=t.getId()%></td>
<td><%=t.getTeacherId()%></td>
<td><%=t.getFullName()%></td>
<td><%=t.getEmail()%></td>
<td><%=t.getPhone()%></td>
<td><%=t.getDepartment()%></td>
<td><%=t.getQualification()%></td>

<td>
   <td>

<a href="${pageContext.request.contextPath}/EditTeacherServlet?id=<%=t.getId()%>"
   class="btn edit">Edit</a>

<a href="${pageContext.request.contextPath}/DeleteTeacherServlet?id=<%=t.getId()%>"
   class="btn delete"
   onclick="return confirm('Are you sure you want to delete this teacher?');">
   Delete
</a>

</td>
</td>

</tr>

<%
    }
}
%>

</table>

</body>
</html>