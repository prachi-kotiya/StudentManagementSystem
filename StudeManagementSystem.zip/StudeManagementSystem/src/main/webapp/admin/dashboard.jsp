<%@ page contentType="text/html;charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>

<style>

body{
    margin:0;
    font-family:Arial;
    background:#f4f6f9;
}

.sidebar{
    position:fixed;
    width:230px;
    height:100vh;
    background:#2c3e50;
    color:white;
}

.sidebar h2{
    text-align:center;
    padding:20px;
}

.sidebar a{
    display:block;
    color:white;
    padding:15px 25px;
    text-decoration:none;
}

.sidebar a:hover{
    background:#34495e;
}

.main{
    margin-left:230px;
    padding:30px;
}

.cards{
    display:flex;
    gap:20px;
    margin-top:20px;
}

.card{
    flex:1;
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 3px 10px rgba(0,0,0,.1);
}

.card h3{
    margin:0;
    color:#777;
}

.card h1{
    margin-top:15px;
    color:#2c3e50;
}

</style>

</head>

<body>

<div class="sidebar">

<h2>SMS Admin</h2>

<a href="${pageContext.request.contextPath}/AdminDashboardServlet">Dashboard</a>

<a href="${pageContext.request.contextPath}/StudentsServlet">Students</a>

<a href="${pageContext.request.contextPath}/TeachersServlet">Teachers</a>

<a href="#">Parents</a>

<a href="#">Courses</a>

<a href="#">Attendance</a>

<a href="#">Notices</a>

<a href="#">Settings</a>

</div>

<div class="main">

<h1>Dashboard</h1>

<div class="cards">

<div class="card">
<h3>Total Students</h3>
<h1>${totalStudents}</h1>
</div>

<div class="card">
<h3>Total Teachers</h3>
<h1>${totalTeachers}</h1>
</div>

<div class="card">
<h3>Total Parents</h3>
<h1>0</h1>
</div>

<div class="card">
<h3>Total Courses</h3>
<h1>0</h1>
</div>

</div>

</div>

</body>
</html>