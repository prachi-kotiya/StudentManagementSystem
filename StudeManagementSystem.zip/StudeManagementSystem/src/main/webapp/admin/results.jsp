<%@page import="java.util.List"%>
<%@page import="com.sms.model.Result"%>

<%
List<Result> resultList = (List<Result>) request.getAttribute("resultList");
%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Student Results</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container mt-5">

<div class="card shadow">

<div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">

<h3>Student Results</h3>

<a href="add-result.jsp" class="btn btn-light">
Add Result
</a>

</div>

<div class="card-body">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>
<th>Student</th>
<th>Subject</th>
<th>Marks</th>
<th>Grade</th>
<th>Exam Date</th>
<th width="170">Action</th>

</tr>

</thead>

<tbody>

<%
if(resultList != null){

for(Result result : resultList){
%>

<tr>

<td><%=result.getId()%></td>

<td><%=result.getStudentName()%></td>

<td><%=result.getSubject()%></td>

<td><%=result.getMarks()%></td>

<td>

<%
String grade = result.getGrade();

if(grade.equals("A+") || grade.equals("A")){
%>

<span class="badge bg-success"><%=grade%></span>

<%
}else if(grade.equals("B+") || grade.equals("B")){
%>

<span class="badge bg-primary"><%=grade%></span>

<%
}else if(grade.equals("C")){
%>

<span class="badge bg-warning text-dark"><%=grade%></span>

<%
}else{
%>

<span class="badge bg-danger"><%=grade%></span>

<%
}
%>

</td>

<td><%=result.getExamDate()%></td>

<td>

<a href="${pageContext.request.contextPath}/EditResultServlet?id=<%=result.getId()%>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="${pageContext.request.contextPath}/DeleteResultServlet?id=<%=result.getId()%>"
class="btn btn-danger btn-sm"
onclick="return confirm('Are you sure you want to delete this result?');">

Delete

</a>

</td>

</tr>

<%
}
}
%>

</tbody>

</table>

</div>

</div>

</div>

</body>

</html>