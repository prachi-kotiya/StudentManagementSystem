<%@ page contentType="text/html;charset=UTF-8"%>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Add Attendance</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container mt-5">

<h2>Add Attendance</h2>

<form action="${pageContext.request.contextPath}/AddAttendanceServlet"
method="post">

<div class="mb-3">

<label>Student ID</label>

<input
type="number"
name="studentId"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Date</label>

<input
type="date"
name="attendanceDate"
class="form-control"
required>

</div>

<div class="mb-3">

<label>Status</label>

<select
name="status"
class="form-select">

<option value="Present">Present</option>

<option value="Absent">Absent</option>

<option value="Late">Late</option>

<option value="Leave">Leave</option>

</select>

</div>

<button class="btn btn-success">

Save Attendance

</button>

</form>

</div>

</body>

</html>