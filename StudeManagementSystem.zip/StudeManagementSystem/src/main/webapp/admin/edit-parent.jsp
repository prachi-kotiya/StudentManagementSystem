<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.sms.model.Parent" %>

<%
Parent parent = (Parent) request.getAttribute("parent");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Edit Parent</title>

<style>

body{
    font-family:Arial;
    background:#f4f6f9;
    padding:30px;
}

.container{
    width:500px;
    margin:auto;
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 3px 10px rgba(0,0,0,.1);
}

input,textarea{
    width:100%;
    padding:10px;
    margin:8px 0;
    box-sizing:border-box;
}

button{
    background:#4CAF50;
    color:white;
    border:none;
    padding:10px 20px;
    cursor:pointer;
}

</style>

</head>

<body>

<div class="container">

<h2>Edit Parent</h2>

<form action="${pageContext.request.contextPath}/UpdateParentServlet" method="post">

<input type="hidden" name="id" value="<%=parent.getId()%>">

<label>Parent ID</label>
<input type="text" name="parentId" value="<%=parent.getParentId()%>" required>

<label>Full Name</label>
<input type="text" name="fullName" value="<%=parent.getFullName()%>" required>

<label>Email</label>
<input type="email" name="email" value="<%=parent.getEmail()%>" required>

<label>Phone</label>
<input type="text" name="phone" value="<%=parent.getPhone()%>" required>

<label>Occupation</label>
<input type="text" name="occupation" value="<%=parent.getOccupation()%>" required>

<label>Address</label>
<textarea name="address"><%=parent.getAddress()%></textarea>

<br><br>

<button type="submit">Update Parent</button>

</form>

</div>

</body>
</html>