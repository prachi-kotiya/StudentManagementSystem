<%@page import="java.util.List"%>
<%@page import="com.sms.model.Attendance"%>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Attendance List</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container mt-5">

<h2>Attendance List</h2>

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th>ID</th>
<th>Student</th>
<th>Date</th>
<th>Status</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<%

List<Attendance> list = (List<Attendance>)request.getAttribute("attendanceList");

if(list!=null){

for(Attendance a : list){

%>

<tr>

<td><%=a.getId()%></td>

<td><%=a.getStudentName()%></td>

<td><%=a.getAttendanceDate()%></td>

<td>
<%
if(a.getStatus().equals("Present")){
%>
<span class="badge bg-success">Present</span>
<%
}else if(a.getStatus().equals("Absent")){
%>
<span class="badge bg-danger">Absent</span>
<%
}else if(a.getStatus().equals("Late")){
%>
<span class="badge bg-warning text-dark">Late</span>
<%
}else{
%>
<span class="badge bg-primary">Leave</span>
<%
}
%>
</td>

<td>

<a href="EditAttendanceServlet?id=<%=a.getId()%>"
class="btn btn-warning btn-sm">

Edit

</a>

<a href="DeleteAttendanceServlet?id=<%=a.getId()%>"
class="btn btn-danger btn-sm"
onclick="return confirm('Delete this attendance?')">

Delete

</a>

</td>

</tr>

<%

}

}

%>

</tbody>

</table>

</div>

</body>

</html>